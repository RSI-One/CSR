/**
 * RSI Capital Management System — Local Server
 * Run: node server.js
 * Then open: http://localhost:3000
 */

const http = require('http');
const fs   = require('fs');
const path = require('path');

const PORT = 3000;
const FILE = path.join(__dirname, 'RSI_CMS_Standalone.html');

const server = http.createServer((req, res) => {
  // Serve the main app
  if (req.url === '/' || req.url === '/index.html') {
    try {
      const html = fs.readFileSync(FILE, 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(html);
    } catch (e) {
      res.writeHead(404);
      res.end('RSI_CMS_Standalone.html not found. Make sure it is in the same folder.');
    }
    return;
  }
  // Health check
  if (req.url === '/ping') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('RSI CMS Server running ✓');
    return;
  }
  res.writeHead(404);
  res.end('Not found');
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('╔══════════════════════════════════════════════╗');
  console.log('║   RSI Capital Management System — RUNNING   ║');
  console.log('╠══════════════════════════════════════════════╣');
  console.log(`║   Open in browser: http://localhost:${PORT}     ║`);
  console.log('║   Press Ctrl+C to stop the server           ║');
  console.log('╚══════════════════════════════════════════════╝');
  console.log('');

  // Auto-open browser
  const { exec } = require('child_process');
  const url = `http://localhost:${PORT}`;
  const cmd = process.platform === 'win32'  ? `start ${url}`
            : process.platform === 'darwin' ? `open ${url}`
            : `xdg-open ${url}`;
  exec(cmd, err => { if (err) console.log(`Open manually: ${url}`); });
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log(`\nPort ${PORT} is busy. Try closing other apps and run again.\n`);
  } else {
    console.error('Server error:', err.message);
  }
  process.exit(1);
});

// Keep server alive
process.on('SIGINT', () => {
  console.log('\nServer stopped. Goodbye!\n');
  process.exit(0);
});
