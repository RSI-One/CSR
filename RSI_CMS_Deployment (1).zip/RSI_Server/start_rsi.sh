#!/bin/bash
echo ""
echo "  =========================================="
echo "   RSI Capital Management System"
echo "  =========================================="
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "  [ERROR] Node.js is not installed!"
    echo ""
    echo "  Install it:"
    echo "  Mac:   brew install node   (or download from nodejs.org)"
    echo "  Linux: sudo apt install nodejs"
    echo ""
    exit 1
fi

echo "  Starting RSI CMS Server..."
echo "  Browser will open automatically."
echo "  Press Ctrl+C to stop."
echo ""

node "$(dirname "$0")/server.js"
