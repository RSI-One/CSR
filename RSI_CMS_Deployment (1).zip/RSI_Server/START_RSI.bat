@echo off
title RSI Capital Management System
color 0A
echo.
echo  ==========================================
echo   RSI Capital Management System
echo  ==========================================
echo.

:: Check if Node.js is installed
node --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Node.js is not installed!
    echo.
    echo  Please install Node.js first:
    echo  1. Go to https://nodejs.org
    echo  2. Download and install the LTS version
    echo  3. Run this file again
    echo.
    pause
    exit /b 1
)

echo  Starting RSI CMS Server...
echo  Browser will open automatically.
echo.
echo  To STOP the server: press Ctrl+C
echo  To RESTART: close this window and double-click START_RSI.bat again
echo.

:: Start the server
node "%~dp0server.js"

pause
