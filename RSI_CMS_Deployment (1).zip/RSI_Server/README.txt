RSI CAPITAL MANAGEMENT SYSTEM — SETUP GUIDE
============================================

WHAT'S IN THIS FOLDER
----------------------
  RSI_CMS_Standalone.html   ← The actual app (all in one file)
  server.js                 ← Local web server
  START_RSI.bat             ← Windows: double-click to launch
  start_rsi.sh              ← Mac/Linux: run to launch
  README.txt                ← This file


OPTION A — SIMPLEST (just the HTML file)
-----------------------------------------
  1. Double-click  RSI_CMS_Standalone.html
  2. It opens in your browser
  3. Done — data saves automatically

  REQUIREMENT: Internet connection (first time only, to load fonts/React)
  NOTE: Use Chrome or Edge for best results


OPTION B — LOCAL SERVER (recommended, works offline)
-----------------------------------------------------
  STEP 1: Install Node.js (one time only)
    → Go to  https://nodejs.org
    → Download "LTS" version
    → Install it (just click Next, Next, Finish)

  STEP 2: Start the server
    → Windows: Double-click  START_RSI.bat
    → Mac/Linux: Run  bash start_rsi.sh

  STEP 3: App opens automatically in your browser
    → URL: http://localhost:3000

  STEP 4: To stop — close the black server window
  STEP 5: To use again — double-click START_RSI.bat


BACKING UP YOUR DATA
--------------------
  Inside the app, at the bottom of the left sidebar:
  → Click "⬇ Backup"  — downloads all data as a JSON file
  → Click "⬆ Restore" — loads data from a backup file

  IMPORTANT: Back up regularly! Data is stored in the browser.
  If you clear browser history/cache, your data will be lost.
  Always keep a recent backup on a USB stick or cloud storage.


MOVING TO A NEW PC
------------------
  1. On old PC: Click "⬇ Backup" in the app
  2. Copy the backup JSON file + this whole folder to new PC
  3. Set up the server on new PC (Option B above)
  4. Open the app, click "⬆ Restore", select your backup file
  5. All data restored!


MULTIPLE USERS / NETWORK ACCESS
--------------------------------
  To let other PCs on the same network access RSI CMS:
  1. Change 127.0.0.1 to 0.0.0.0 in server.js (line 34)
  2. Find your PC's IP address (run: ipconfig on Windows)
  3. Other PCs open: http://YOUR_IP:3000
  Note: All users share the same data (stored on the server PC)


SUPPORT
-------
  Developed for RSI Capital Management, Rawalpindi
  Version: v10 | 2026


============================================
